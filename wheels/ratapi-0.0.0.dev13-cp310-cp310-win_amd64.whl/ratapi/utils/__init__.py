"""Additional utilities for ratapi."""
